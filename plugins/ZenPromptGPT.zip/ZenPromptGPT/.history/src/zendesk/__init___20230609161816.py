import os

from auto_gpt_plugin_template import AutoGPTPluginTemplate
from typing import Any, Dict, List, Optional, Tuple, TypeVar, TypedDict
from .zendesk import Zendesk

PromptGenerator = TypeVar("PromptGenerator")


class Message(TypedDict):
    role: str
    content: str


class ZendeskPromptGPT(AutoGPTPluginTemplate):
    """
    This is a plugin for AutoGPT that can interact with Zendesk APIs. It primarily
    talks to Support and Sunshine Conversations as a start
    """

    def __init__(self):
        super().__init__()
        self._name = "ZendeskPromptGPT"
        self._version = "0.1.0"
        self._description = "This integrates Zendesk API with AutoGPT"
        self.zendesk_api_token = os.getenv("ZENDESK_API_TOKEN")
        self.zendesk_subdomain = os.getenv("ZENDESK_SUBDOMAIN")
        self.zendesk_email = os.getenv("ZENDESK_EMAIL")
        self.zendesk = Zendesk(
            zendesk_email=self.zendesk_email,
            zendesk_api_token=self.zendesk_api_token,
            subdomain=self.zendesk_subdomain,
        )

    def can_handle_on_response(self) -> bool:
        """This method is called to check that the plugin can
        handle the on_response method.

        Returns:
            bool: True if the plugin can handle the on_response method."""
        return False

    def on_response(self, response: str, *args, **kwargs) -> str:
        """This method is called when a response is received from the model."""
        pass

    def can_handle_post_prompt(self) -> bool:
        """This method is called to check that the plugin can
        handle the post_prompt method.

        Returns:
            bool: True if the plugin can handle the post_prompt method."""
        return True

    def post_prompt(self, prompt: PromptGenerator) -> PromptGenerator:
        """This method is called just after the generate_prompt is called,
            but actually before the prompt is generated.

        Args:
            prompt (PromptGenerator): The prompt generator.

        Returns:
            PromptGenerator: The prompt generator.
        """

        prompt.add_constraint(
            "Agents should refer to Zendesk agents and not autonomous agents"
        )

        prompt.add_command(
            "List tickets",
            "list_tickets",
            {
                "after_datetime": "<datetime in '%Y-%m-%dT%H:%m:%S+%H:%m' format>",
                "status": "<a list of of statuses e.g. new, open, pending, hold, solved, closed. Defaults to [\"open\",\"pending\",\"new\"]>",
            },
            self.zendesk.list_tickets,
        )

        prompt.add_command(
            "Search for tickets",
            "search_tickets",
            {
                "query": "<query using the article https://support.zendesk.com/hc/en-us/articles/4408886879258>",
                "after_datetime": "<datetime in '%Y-%m-%dT%H:%m:%S+%H:%m' format>",
                "status": "<a list of of statuses e.g. new, open, pending, hold, solved, closed. Defaults to [\"open\",\"pending\",\"new\"]>",
            },
            self.zendesk.search_tickets,
        )

        prompt.add_command(
            "List and read the contents of tickets that have statuses less than \"pending\" status",
            "list_and_read_tickets",
            {
                "after_datetime": "<datetime in '%Y-%m-%dT%H:%m:%S+00:00' format>",
                "status": "<a list of of statuses e.g. new, open, pending, hold, solved, closed.>",
            },
            self.zendesk.list_and_read_tickets,
        )

        prompt.add_command(
            "Read a ticket which contains metadata like conversation_id if it's a Messaging ticket and chat_id if it's a Chat ticket",
            "read_ticket",
            {"ticket_id": "<id of a ticket>"},
            self.zendesk.read_ticket,
        )

        prompt.add_command(
            "Reassign a ticket to an agent and apply optional status and tags",
            "reassign_ticket_to_agent",
            {
                "ticket_id": "<ticket id>",
                "assignee_id": "<agent id that the ticket should be assigned to>",
                "status": "<optional ticket status>",
                "tags": "<optional tags>",
            },
            self.zendesk.reassign_ticket_to_agent,
        )

        prompt.add_command(
            "Add tags to a ticket",
            "add_tags_to_ticket",
            {"ticket_id": "<ticket id>", "tags": "<list of tags to be added>"},
            self.zendesk.add_tags_to_ticket,
        )

        prompt.add_command(
            "Remove tags from a ticket",
            "remove_tags_from_ticket",
            {"ticket_id": "<ticket id>", "tags": "<list of tags to be removed>"},
            self.zendesk.remove_tags_from_ticket,
        )

        prompt.add_command(
            "Change the ticket status of a ticket to one of the following: new, open, pending, hold, solved, closed",
            "change_ticket_status",
            {
                "ticket_id": "<ticket id>",
                "status": "<ticket status>",
            },
            self.zendesk.change_ticket_status,
        )

        prompt.add_command(
            "Reassign a ticket to a group and apply optional status and tags",
            "reassign_ticket_to_group",
            {
                "ticket_id": "<ticket id>",
                "group_id": "<group id>",
                "status": "<optional ticket status>",
                "tags": "<optional list of tags>",
            },
            self.zendesk.reassign_ticket_to_group,
        )

        prompt.add_command(
            "Search Zendesk Help Center Articles and return a list of links to the articles in json format",
            "search_helpcenter",
            {"query": "<query>"},
            self.zendesk.search_helpcenter,
        )

        prompt.add_command(
            "List Zendesk groups",
            "list_zendesk_groups",
            {},
            self.zendesk.list_zendesk_groups,
        )

        prompt.add_command(
            "List Zendesk agents",
            "list_zendesk_agents",
            {},
            self.zendesk.list_zendesk_agents,
        )

        prompt.add_command(
            "List Zendesk users",
            "list_zendesk_users",
            {
                "role": ["<optional role>", "<optional role>"],
            },
            self.zendesk.list_zendesk_users,
        )

        prompt.add_command(
            "List Triggers",
            "list_triggers",
            {"active_only": "<optional boolean to show only active triggers>"},
            self.zendesk.list_triggers,
        )

        prompt.add_command(
            "Create Trigger",
            "create_trigger",
            {"trigger": "<trigger of str type from Zendesk Trigger API>"},
            self.zendesk.create_trigger,
        )

        prompt.add_command(
            "Delete Trigger",
            "delete_trigger",
            {"id": "<id of trigger to be deleted>"},
            self.zendesk.delete_trigger,
        )

        prompt.add_command(
            "Update Trigger",
            "update_trigger",
            {"trigger": "<trigger of str type from Zendesk Trigger API>"},
            self.zendesk.update_trigger,
        )

        prompt.add_command(
            "Show a trigger",
            "show_trigger",
            {"id": "<trigger id>"},
            self.zendesk.show_trigger,
        )

        prompt.add_command(
            "Reorder the triggers based on the order of the trigger ids",
            "reorder_triggers",
            {"trigger_ids": "<trigger ids in a list>"},
            self.zendesk.reorder_triggers,
        )

        prompt.add_command(
            "List Macros",
            "list_macros",
            {"active_only": "<optional boolean to show only active macros>"},
            self.zendesk.list_macros,
        )

        prompt.add_command(
            "Create Macro",
            "create_macro",
            {"macro": "<macro of str type from Zendesk Macro API>"},
            self.zendesk.create_macro,
        )

        prompt.add_command(
            "Update Macro",
            "update_macro",
            {"macro": "<macro in str format from Zendesk Macro API>"},
            self.zendesk.update_macro,
        )

        prompt.add_command(
            "Show a macro",
            "show_macro",
            {"id": "<macro id>"},
            self.zendesk.show_macro,
        )

        prompt.add_command(
            "Delete Macro",
            "delete_macro",
            {"id": "<id of macro be deleted>"},
            self.zendesk.delete_macro,
        )

        prompt.add_command(
            "List Views",
            "list_views",
            {"active_only": "<optional boolean to show only active views>"},
            self.zendesk.list_views,
        )

        prompt.add_command(
            "Create View",
            "create_view",
            {"view": "<view of str type from Zendesk View API>"},
            self.zendesk.create_view,
        )

        prompt.add_command(
            "Update View",
            "update_view",
            {"view": "<view of str format from Zendesk View API>"},
            self.zendesk.update_view,
        )

        prompt.add_command(
            "Show a view",
            "show_view",
            {"id": "<view id>"},
            self.zendesk.show_view,
        )

        prompt.add_command(
            "Delete View",
            "delete_view",
            {"id": "<id of view to be deleted>"},
            self.zendesk.delete_view,
        )

        return prompt

    def can_handle_on_planning(self) -> bool:
        """This method is called to check that the plugin can
        handle the on_planning method.

        Returns:
            bool: True if the plugin can handle the on_planning method."""
        return False

    def on_planning(
        self, prompt: PromptGenerator, messages: List[Message]
    ) -> Optional[str]:
        """This method is called before the planning chat completion is done.

        Args:
            prompt (PromptGenerator): The prompt generator.
            messages (List[str]): The list of messages.
        """
        pass

    def can_handle_post_planning(self) -> bool:
        """This method is called to check that the plugin can
        handle the post_planning method.

        Returns:
            bool: True if the plugin can handle the post_planning method."""
        return False

    def post_planning(self, response: str) -> str:
        """This method is called after the planning chat completion is done.

        Args:
            response (str): The response.

        Returns:
            str: The resulting response.
        """
        pass

    def can_handle_pre_instruction(self) -> bool:
        """This method is called to check that the plugin can
        handle the pre_instruction method.

        Returns:
            bool: True if the plugin can handle the pre_instruction method."""
        return False

    def pre_instruction(self, messages: List[Message]) -> List[Message]:
        """This method is called before the instruction chat is done.

        Args:
            messages (List[Message]): The list of context messages.

        Returns:
            List[Message]: The resulting list of messages.
        """
        pass

    def can_handle_on_instruction(self) -> bool:
        """This method is called to check that the plugin can
        handle the on_instruction method.

        Returns:
            bool: True if the plugin can handle the on_instruction method."""
        return False

    def on_instruction(self, messages: List[Message]) -> Optional[str]:
        """This method is called when the instruction chat is done.

        Args:
            messages (List[Message]): The list of context messages.

        Returns:
            Optional[str]: The resulting message.
        """
        pass

    def can_handle_post_instruction(self) -> bool:
        """This method is called to check that the plugin can
        handle the post_instruction method.

        Returns:
            bool: True if the plugin can handle the post_instruction method."""
        return False

    def post_instruction(self, response: str) -> str:
        """This method is called after the instruction chat is done.

        Args:
            response (str): The response.

        Returns:
            str: The resulting response.
        """
        pass

    def can_handle_pre_command(self) -> bool:
        """This method is called to check that the plugin can
        handle the pre_command method.

        Returns:
            bool: True if the plugin can handle the pre_command method."""
        return False

    def pre_command(
        self, command_name: str, arguments: Dict[str, Any]
    ) -> Tuple[str, Dict[str, Any]]:
        """This method is called before the command is executed.

        Args:
            command_name (str): The command name.
            arguments (Dict[str, Any]): The arguments.

        Returns:
            Tuple[str, Dict[str, Any]]: The command name and the arguments.
        """
        pass

    def can_handle_post_command(self) -> bool:
        """This method is called to check that the plugin can
        handle the post_command method.

        Returns:
            bool: True if the plugin can handle the post_command method."""
        return False

    def post_command(self, command_name: str, response: str) -> str:
        """This method is called after the command is executed.

        Args:
            command_name (str): The command name.
            response (str): The response.

        Returns:
            str: The resulting response.
        """
        pass

    def can_handle_chat_completion(
        self, messages: Dict[Any, Any], model: str, temperature: float, max_tokens: int
    ) -> bool:
        """This method is called to check that the plugin can
          handle the chat_completion method.

        Args:
            messages (List[Message]): The messages.
            model (str): The model name.
            temperature (float): The temperature.
            max_tokens (int): The max tokens.

          Returns:
              bool: True if the plugin can handle the chat_completion method."""
        return False

    def handle_chat_completion(
        self, messages: List[Message], model: str, temperature: float, max_tokens: int
    ) -> str:
        """This method is called when the chat completion is done.

        Args:
            messages (List[Message]): The messages.
            model (str): The model name.
            temperature (float): The temperature.
            max_tokens (int): The max tokens.

        Returns:
            str: The resulting response.
        """
        pass

    def can_handle_text_embedding(self, text: str) -> bool:
        """This method is called to check that the plugin can
          handle the text_embedding method.
        Args:
            text (str): The text to be convert to embedding.
          Returns:
              bool: True if the plugin can handle the text_embedding method."""
        return False

    def handle_text_embedding(self, text: str) -> list:
        """This method is called when the chat completion is done.
        Args:
            text (str): The text to be convert to embedding.
        Returns:
            list: The text embedding.
        """
        pass

    def can_handle_user_input(self, user_input: str) -> bool:
        """This method is called to check that the plugin can
        handle the user_input method.

        Args:
            user_input (str): The user input.

        Returns:
            bool: True if the plugin can handle the user_input method."""
        return False

    def user_input(self, user_input: str) -> str:
        """This method is called to request user input to the user.

        Args:
            user_input (str): The question or prompt to ask the user.

        Returns:
            str: The user input.
        """

        pass

    def can_handle_report(self) -> bool:
        """This method is called to check that the plugin can
        handle the report method.

        Returns:
            bool: True if the plugin can handle the report method."""
        return False

    def report(self, message: str) -> None:
        """This method is called to report a message to the user.

        Args:
            message (str): The message to report.
        """
        pass
