import sunshine_conversations_client
import zenpy
import json

from datetime import datetime, timezone


class Zendesk:
    def __init__(
        self,
        zendesk_email: str = None,
        zendesk_api_token: str = None,
        subdomain: str = None,
        sunco_api_key: str = None,
        sunco_api_secret: str = None,
    ):
        self.sunco_api_key = sunco_api_key
        self.sunco_api_secret = sunco_api_secret
        self.zenpy_client = zenpy.Zenpy(
            email=zendesk_email, token=zendesk_api_token, subdomain=subdomain
        )
        configuration = sunshine_conversations_client.Configuration(
            host="https://api.smooch.io"
        )
        self.sunco_client = sunshine_conversations_client.ApiClient(configuration)

    def __parse_ticket(self, ticket: dict) -> dict:
        return {
            "ticket_id": ticket["id"],
            "description": ticket["description"],
            "requester_id": ticket["requester_id"],
            "assignee_id": ticket["assignee_id"],
        }

    def list_tickets(
        self, page_size: int = 1, status: str = "new", after_datetime: str = "today"
    ) -> str:
        response = self.zenpy_client.search(
            type="ticket",
            sort_by="created_at",
            sort_order="asc",
            status=status,
            created_after=after_datetime,
        )
        tickets = [self.__parse_ticket(ticket) for ticket in response]
        return json.dumps(tickets)

    def read_ticket(self, ticket_id: str) -> str:
        comments = self.zenpy_client.tickets.comments(ticket=ticket_id)

        ticket = {id: ticket_id, comments: [comment.body for comment in comments]}
        return json.dumps(ticket)

    def list_and_read_new_tickets(
        self, page_size: int = 1, status: str = "new", after_datetime: str = "today"
    ) -> str:
        response = self.zenpy_client.search(
            type="ticket",
            sort_by="created_at",
            sort_order="asc",
            status=status,
            created_after=after_datetime,
        )
        tickets = [
            self.__parse_ticket(ticket)
            for ticket in response
        ]
        for ticket in tickets:
            ticket["comments"] = [
                comment.body
                for comment in self.zenpy_client.tickets.comments(ticket=ticket.id)
            ]

        return json.dumps(tickets)

    def list_groups(self, page_size: int = 1) -> str:
        groups = self.zenpy_client.groups(page_size=page_size)
        return json.dumps(
            [
                {
                    "group_id": group.id,
                    "group_name": group.name,
                    "group_description": group.description,
                }
                for group in groups
            ]
        )

    def reassign_ticket_to_group(self, ticket_id: str, group_id: str) -> dict:
        ticket = self.zenpy_client.tickets(id=ticket_id)
        ticket.group_id = group_id
        return self.zenpy_client.tickets.update(ticket)

    def reassign_ticket_to_agent(self, ticket_id: str, assignee_id: str) -> dict:
        ticket = self.zenpy_client.tickets(id=ticket_id)
        ticket.assignee_id = assignee_id
        return self.zenpy_client.tickets.update(ticket)

    def search_helpcenter(self, query: str) -> list:
        zenpy_client = zenpy.Zenpy(token=self.support_api_token)
        return zenpy_client.help_center(query=query)
