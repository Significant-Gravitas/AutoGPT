import zenpy
import json
import requests


class Zendesk:
    def __init__(
        self,
        zendesk_email: str = None,
        zendesk_api_token: str = None,
        subdomain: str = None,
    ):
        self.subdomain = subdomain
        self.zendesk_email = zendesk_email
        self.zendesk_api_token = zendesk_api_token
        self.zenpy_client = zenpy.Zenpy(
            email=zendesk_email, token=zendesk_api_token, subdomain=subdomain
        )

    def __parse_ticket(self, ticket: dict) -> dict:
        return {
            "id": ticket.id,
            "description": ticket.description,
            "requester_id": ticket.requester_id,
            "assignee_id": ticket.assignee_id,
        }

    def search_tickets(
        self,
        query: str,
        page_size: int = 1,
        status: str = "new",
        after_datetime: str = "1days",
    ) -> str:
        return self.list_tickets(
            query=query,
            page_size=page_size,
            status=status,
            after_datetime=after_datetime,
        )

    def list_tickets(
        self,
        query=None,
        page_size: int = 1,
        status: str = "new",
        after_datetime: str = "1days",
    ) -> str:
        response = self.zenpy_client.search(
            query=query,
            type="ticket",
            sort_by="created_at",
            sort_order="asc",
            status=status,
            created_after=after_datetime,
        )
        tickets = [self.__parse_ticket(ticket) for ticket in response]
        return json.dumps(tickets)

    def read_ticket(self, ticket_id: str) -> str:
        comments = self.zenpy_client.tickets.comments(ticket=ticket_id)

        ticket = {"id": ticket_id, "comments": [comment.body for comment in comments]}
        return json.dumps(ticket)

    def list_and_read_new_tickets(
        self, page_size: int = 1, status: str = "new", after_datetime: str = "1days"
    ) -> str:
        response = self.zenpy_client.search(
            type="ticket",
            sort_by="created_at",
            sort_order="asc",
            status=status,
            created_after=after_datetime,
        )
        tickets = [self.__parse_ticket(ticket) for ticket in response]
        for ticket in tickets:
            ticket["comments"] = [
                comment.body
                for comment in self.zenpy_client.tickets.comments(ticket=ticket["id"])
            ]

        return json.dumps(tickets)

    def list_groups(self, page_size: int = 1) -> str:
        groups = self.zenpy_client.groups(page_size=page_size)
        return json.dumps(
            [
                {
                    "group_id": group.id,
                    "group_name": group.name,
                    "group_description": group.description,
                }
                for group in groups
            ]
        )

    def list_users(self, role=None, page_size: int = 1) -> str:
        if role:
            users = self.zenpy_client.users(role=role, page_size=page_size)
        else:
            users = self.zenpy_client.users(page_size=page_size)
        return json.dumps(
            [
                {
                    "id": user.id,
                    "name": user.name,
                    "email": user.email,
                    "role": user.role,
                }
                for user in users
            ]
        )

    def list_agents(self, page_size: int = 1) -> str:
        return self.list_users(role=["agent", "admin"], page_size=page_size)

    def change_ticket_status(self, ticket_id: str, status: str = None) -> dict:
        ticket = self.zenpy_client.tickets(id=ticket_id)
        ticket.status = status
        return self.zenpy_client.tickets.update(ticket)

    def reassign_ticket_to_group(
        self, ticket_id: str, group_id: str, status: str = None, tags: list = None
    ) -> dict:
        ticket = self.zenpy_client.tickets(id=ticket_id)
        ticket.group_id = group_id
        if status:
            ticket.status = status
        if tags:
            ticket.tags = tags
        return self.zenpy_client.tickets.update(ticket)

    def reassign_ticket_to_agent(
        self, ticket_id: str, assignee_id: str, status: str = None, tags: list = None
    ) -> dict:
        ticket = self.zenpy_client.tickets(id=ticket_id)
        ticket.assignee_id = assignee_id
        if status:
            ticket.status = status
        if tags:
            ticket.tags = tags
        return self.zenpy_client.tickets.update(ticket)

    def search_helpcenter(self, query):
        url = f"https://{self.subdomain}.zendesk.com/api/v2/help_center/articles/search.json"
        params = {
            "query": query,
        }
        auth = (
            self.zendesk_email + "/token",
            self.zendesk_api_token,
        )  # Use API token for authentication
        response = requests.get(url, params=params, auth=auth)
        response.raise_for_status()

        return [article["url"] for article in response.json().get("results", [])]

    def list_triggers(self, active_only=True):
        triggers = self.zenpy_client.triggers(active=active_only)
        return json.dumps(
            [
                {
                    "id": trigger.id,
                    "title": trigger.title,
                    "description": trigger.description,
                    "active": trigger.active,
                }
                for trigger in triggers
            ]
        )

    def show_trigger(self, trigger_id):
        trigger = self.zenpy_client.triggers(id=trigger_id)
        return json.dumps(
            {
                "id": trigger.id,
                "title": trigger.title,
                "description": trigger.description,
                "active": trigger.active,
            }
        )

    def reorder_triggers(self, trigger_ids: list):
        return self.zenpy_client.triggers.reorder(trigger_ids)

    def create_trigger(self, trigger: str) -> zenpy.lib.api_objects.Trigger:
        trigger_obj = json.loads(
            trigger, object_hook=lambda d: zenpy.lib.api_objects.Trigger(**d)
        )
        return self.zenpy_client.triggers.create(trigger_obj)

    def update_trigger(self, trigger: str) -> zenpy.lib.api_objects.Trigger:
        trigger_obj = json.loads(
            trigger, object_hook=lambda d: zenpy.lib.api_objects.Trigger(**d)
        )
        return self.zenpy_client.triggers.update(trigger_obj)

    def list_macros(self, active_only=True):
        macros = self.zenpy_client.macros(active=active_only)
        return json.dumps(
            [
                {
                    "id": macro.id,
                    "title": macro.title,
                    "description": macro.description,
                    "active": macro.active,
                }
                for macro in macros
            ]
        )

    def delete_trigger(self, trigger_id):
        return self.zenpy_client.triggers.delete(trigger_id)

    def create_macro(self, macro: str) -> zenpy.lib.api_objects.Macro:
        macro_obj = json.loads(
            macro, object_hook=lambda d: zenpy.lib.api_objects.Macro(**d)
        )
        return self.zenpy_client.macros.create(macro_obj)

    def update_macro(self, macro: str) -> zenpy.lib.api_objects.Macro:
        macro_obj = json.loads(
            macro, object_hook=lambda d: zenpy.lib.api_objects.Macro(**d)
        )
        return self.zenpy_client.macros.update(macro_obj)

    def show_macro(self, id):
        macro = self.zenpy_client.macros(macro_id=id)
        return json.dumps(
            {
                "id": macro.id,
                "title": macro.title,
                "description": macro.description,
                "active": macro.active,
            }
        )

    def delete_macro(self, macro_id):
        return self.zenpy_client.macros.delete(macro_id)

    def list_views(self, active_only=True):
        views = self.zenpy_client.views(active=active_only)
        return json.dumps(
            [
                {
                    "id": view.id,
                    "title": view.title,
                    "description": view.description,
                    "active": view.active,
                }
                for view in views
            ]
        )

    def create_view(self, view: str) -> zenpy.lib.api_objects.View:
        view_obj = json.loads(
            view, object_hook=lambda d: zenpy.lib.api_objects.View(**d)
        )
        return self.zenpy_client.views.create(view_obj)

    def update_view(self, view: str) -> zenpy.lib.api_objects.View:
        view_obj = json.loads(
            view, object_hook=lambda d: zenpy.lib.api_objects.View(**d)
        )
        return self.zenpy_client.views.update(view_obj)

    def show_view(self, view_id):
        view = self.zenpy_client.views(id=view_id)
        return json.dumps(
            {
                "id": view.id,
                "title": view.title,
                "description": view.description,
                "active": view.active,
            }
        )

    def delete_view(self, view_id):
        return self.zenpy_client.views.delete(view_id)
