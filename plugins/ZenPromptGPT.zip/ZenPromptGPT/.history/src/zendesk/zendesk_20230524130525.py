import sunshine_conversations_client
import zenpy

class Zendesk:
    def __init__(self, support_api_token: str = None, sunco_api_key: str = None, sunco_api_secret: str = None):
        self.support_api_token = support_api_token
        self.sunco_api_key = sunco_api_key
        self.sunco_api_secret = sunco_api_secret

    def list_tickets(self, page_size: int = 100, after_datetime: str) -> list:
        zenpy_client = zenpy.Zenpy(token=self.support_api_token)
        return zenpy_client.tickets()