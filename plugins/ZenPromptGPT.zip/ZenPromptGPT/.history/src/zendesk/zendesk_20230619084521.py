import zenpy
import json
import requests


class Zendesk:
    def __init__(
        self,
        zendesk_email: str = None,
        zendesk_api_token: str = None,
        subdomain: str = None,
    ):
        self.subdomain = subdomain
        self.zendesk_email = zendesk_email
        self.zendesk_api_token = zendesk_api_token
        self.zenpy_client = zenpy.Zenpy(
            email=zendesk_email, token=zendesk_api_token, subdomain=subdomain
        )

    def __parse_ticket(self, ticket: dict) -> dict:
        return {
            "id": ticket.id,
            "description": ticket.description,
            "requester_id": ticket.requester_id,
            "assignee_id": ticket.assignee_id,
            "group_id": ticket.group_id,
        }

    def search_tickets(
        self,
        query: str,
        status: list = ["open", "pending", "new"],
        after_datetime: str = "1weeks",
    ) -> str:
        return self.list_tickets(
            query=query,
            status=status,
            after_datetime=after_datetime,
        )

    def list_tickets(
        self,
        query=None,
        status: list = ["open", "pending", "new"],
        after_datetime: str = "1weeks",
    ) -> str:
        response = self.zenpy_client.search(
            query=query,
            type="ticket",
            sort_by="created_at",
            sort_order="asc",
            status=status,
            created_after=after_datetime,
        )
        tickets = [self.__parse_ticket(ticket) for ticket in response]
        return json.dumps(tickets)

    def read_ticket(self, ticket_id: str) -> str:
        ticket = self.zenpy_client.tickets(id=ticket_id)
        comments = self.zenpy_client.tickets.comments(ticket=ticket_id)
        audits = self.zenpy_client.tickets.audits(ticket=ticket_id)
        chat_started_events = []
        for audit in audits:
            for event in audit.events:
                if event["type"] == "ChatStartedEvent":
                    chat_started_events.append(
                        {
                            "conversation_id": event["value"]["conversation_id"],
                            "chat_id": event["value"]["chat_id"],
                            "visitor_id": event["value"]["visitor_id"],
                        }
                    )

        ticket_json = self.__parse_ticket(ticket)
        ticket_json["comments"] = [comment.body for comment in comments]
        ticket_json["chat_started_events"] = chat_started_events

        return json.dumps(ticket_json)

    def list_and_read_tickets(
        self,
        tickets: list[int] = None,
    ) -> str:
        response = self.zenpy_client.tickets(
            ids=tickets,
        )
        tickets = [self.__parse_ticket(ticket) for ticket in response]
        for ticket in tickets:
            ticket["comments"] = [
                comment.body
                for comment in self.zenpy_client.tickets.comments(ticket=ticket["id"])
            ]

        return json.dumps(tickets)
    
    def add_comment(
        self,
        body: str = None,
        ticket_id: str = None,
    ) -> str:
        ticket = self.zenpy_client.tickets(id=ticket_id)
        if ticket:
            ticket

    def list_zendesk_groups(self, page_size: int = 1) -> str:
        groups = self.zenpy_client.groups(page_size=page_size)
        return json.dumps(
            [
                {
                    "group_id": group.id,
                    "group_name": group.name,
                    "group_description": group.description,
                }
                for group in groups
            ]
        )

    def list_zendesk_users(self, role=None, page_size: int = 1) -> str:
        if role:
            users = self.zenpy_client.users(role=role, page_size=page_size)
        else:
            users = self.zenpy_client.users(page_size=page_size)
        return json.dumps(
            [
                {
                    "id": user.id,
                    "name": user.name,
                    "email": user.email,
                    "role": user.role,
                }
                for user in users
            ]
        )

    def list_zendesk_agents(self, page_size: int = 1) -> str:
        return self.list_zendesk_users(role=["agent", "admin"], page_size=page_size)

    def change_ticket_status(self, ticket_id: str, status: str = None) -> dict:
        ticket = self.zenpy_client.tickets(id=ticket_id)
        ticket.status = status
        return self.zenpy_client.tickets.update(ticket)

    def add_tags_to_ticket(self, ticket_id: str, tags: list = []) -> dict:
        ticket = self.zenpy_client.tickets(id=ticket_id)
        ticket.tags = ticket.tags + tags
        return self.zenpy_client.tickets.update(ticket)

    def remove_tags_from_ticket(self, ticket_id: str, tags: list = []) -> dict:
        ticket = self.zenpy_client.tickets(id=ticket_id)
        ticket.tags = [t for t in ticket.tags if t not in tags]
        return self.zenpy_client.tickets.update(ticket)

    def reassign_ticket_to_group(
        self, ticket_id: str, group_id: str, status: str = None, tags: list = None
    ) -> dict:
        ticket = self.zenpy_client.tickets(id=ticket_id)
        ticket.group_id = group_id
        if status:
            ticket.status = status
        if tags:
            ticket.tags = tags
        return self.zenpy_client.tickets.update(ticket)

    def reassign_ticket_to_agent(
        self, ticket_id: str, assignee_id: str, status: str = None, tags: list = None
    ) -> dict:
        ticket = self.zenpy_client.tickets(id=ticket_id)
        ticket.assignee_id = assignee_id
        if status:
            ticket.status = status
        if tags:
            ticket.tags = tags
        return self.zenpy_client.tickets.update(ticket)

    def search_helpcenter(self, query):
        url = f"https://{self.subdomain}.zendesk.com/api/v2/help_center/articles/search.json"
        params = {
            "query": query,
        }
        auth = (
            self.zendesk_email + "/token",
            self.zendesk_api_token,
        )  # Use API token for authentication
        response = requests.get(url, params=params, auth=auth)
        response.raise_for_status()

        return [article["url"] for article in response.json().get("results", [])]

    def list_triggers(self, active_only=True):
        triggers = self.zenpy_client.triggers(active=active_only)
        return json.dumps(
            [
                {
                    "id": trigger.id,
                    "title": trigger.title,
                    "description": trigger.description,
                    "active": trigger.active,
                }
                for trigger in triggers
            ]
        )

    def show_trigger(self, id: str):
        result = self.zenpy_client.triggers(trigger_id=id)
        return json.dumps(
            [
                {
                    "id": trigger.id,
                    "title": trigger.title,
                    "description": trigger.description,
                    "active": trigger.active,
                }
                for trigger in result
            ]
        )

    def reorder_triggers(self, trigger_ids: list):
        return self.zenpy_client.triggers.reorder(trigger_ids)

    def create_trigger(self, trigger: str) -> zenpy.lib.api_objects.Trigger:
        if isinstance(trigger, str):
            trigger_obj = json.loads(
                trigger, object_hook=lambda d: zenpy.lib.api_objects.Trigger(**d)
            )
        else:
            trigger_obj = trigger
        return self.zenpy_client.triggers.create(trigger_obj)

    def update_trigger(self, trigger: str) -> zenpy.lib.api_objects.Trigger:
        if isinstance(trigger, str):
            trigger_obj = json.loads(
                trigger, object_hook=lambda d: zenpy.lib.api_objects.Trigger(**d)
            )
        else:
            trigger_obj = trigger
        return self.zenpy_client.triggers.update(trigger_obj)

    def list_macros(self, active_only=True):
        macros = self.zenpy_client.macros(active=active_only)
        return json.dumps(
            [
                {
                    "id": macro.id,
                    "title": macro.title,
                    "description": macro.description,
                    "active": macro.active,
                }
                for macro in macros
            ]
        )

    def delete_trigger(self, id: int):
        trigger = self.zenpy_client.triggers(trigger_id=id)
        if trigger:
            return self.zenpy_client.triggers.delete(api_objects=trigger)
        else:
            return None

    def create_macro(self, macro: str) -> zenpy.lib.api_objects.Macro:
        if isinstance(macro, str):
            macro_obj = json.loads(
                macro, object_hook=lambda d: zenpy.lib.api_objects.Macro(**d)
            )
        else:
            macro_obj = macro
        return self.zenpy_client.macros.create(macro_obj)

    def update_macro(self, macro: str) -> zenpy.lib.api_objects.Macro:
        if isinstance(macro, str):
            macro_obj = json.loads(
                macro, object_hook=lambda d: zenpy.lib.api_objects.Macro(**d)
            )
        else:
            macro_obj = macro
        return self.zenpy_client.macros.update(macro_obj)

    def show_macro(self, id: int):
        result = self.zenpy_client.macros(macro_id=id)
        return json.dumps(
            [
                {
                    "id": macro.id,
                    "title": macro.title,
                    "description": macro.description,
                    "active": macro.active,
                }
                for macro in result
            ]
        )

    def delete_macro(self, id: int):
        macro = self.zenpy_client.macros(macro_id=id)
        if macro:
            return self.zenpy_client.macros.delete(api_objects=macro)
        else:
            return None

    def list_views(self, active_only=True):
        views = self.zenpy_client.views(active=active_only)
        return json.dumps(
            [
                {
                    "id": view.id,
                    "title": view.title,
                    "description": view.description,
                    "active": view.active,
                }
                for view in views
            ]
        )

    def create_view(self, view: str) -> zenpy.lib.api_objects.View:
        if isinstance(view, str):
            view_obj = json.loads(
                view, object_hook=lambda d: zenpy.lib.api_objects.View(**d)
            )
        else:
            view_obj = view
        return self.zenpy_client.views.create(view_obj)

    def update_view(self, view: str) -> zenpy.lib.api_objects.View:
        if isinstance(view, str):
            view_obj = json.loads(
                view, object_hook=lambda d: zenpy.lib.api_objects.View(**d)
            )
        else:
            view_obj = view
        return self.zenpy_client.views.update(view_obj)

    def show_view(self, id: int):
        result = self.zenpy_client.views(view_id=id)
        return json.dumps(
            [
                {
                    "id": view.id,
                    "title": view.title,
                    "description": view.description,
                    "active": view.active,
                }
                for view in result
            ]
        )

    def delete_view(self, id: int):
        view = self.zenpy_client.views(view_id=id)
        if view:
            return self.zenpy_client.views.delete(api_objects=view)
        else:
            return None
