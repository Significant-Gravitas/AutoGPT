import sunshine_conversations_client
import zenpy

class Zendesk:
    def __init__(self, support_api_token: str = None, sunco_api_key: str = None, sunco_api_secret: str = None):
        self.support_api_token = support_api_token
        self.sunco_api_key = sunco_api_key
        self.sunco_api_secret = sunco_api_secret
        self.zenpy_client = zenpy.Zenpy(token=self.support_api_token)
        self.sunco_client = sunco_client();

    @staticmethod
    def sunco_client() -> sunshine_conversations_client.ApiClient: 
        configuration = sunshine_conversations_client.Configuration(
            host = "https://api.smooch.io"
        )
        return sunshine_conversations_client.ApiClient(configuration)

    def list_tickets(self, page_size: int = 100, after_datetime: str = None) -> list:
        return zenpy_client.tickets(page_size=page_size, sort_by='created_at', sort_order='asc', created_after=after_datetime)
    
    def get_ticket(self, ticket_id: str) -> dict:
        zenpy_client = zenpy.Zenpy(token=self.support_api_token)
        return zenpy_client.tickets(id=ticket_id)
    
    def search_helpcenter(self, query: str) -> list:
        zenpy_client = zenpy.Zenpy(token=self.support_api_token)
        return zenpy_client.search(query=query, type='help_center')