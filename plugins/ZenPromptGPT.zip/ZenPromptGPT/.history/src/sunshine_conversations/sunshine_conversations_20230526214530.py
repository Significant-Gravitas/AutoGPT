import json
import sunshine_conversations_client
import time
import jwt


class SunshineConversations:
    def __init__(
        self,
        sunco_app_id: str = None,
        sunco_api_key: str = None,
        sunco_api_secret: str = None,
    ):
        self.sunco_app_id = sunco_app_id
        configuration = sunshine_conversations_client.Configuration(
            host="https://api.smooch.io",
            api_key_prefix="Bearer",
            api_key=get_app_scope_jwt(sunco_api_key, sunco_api_secret, app_id=sunco_app_id)
        )
        self.sunco_client = sunshine_conversations_client.ApiClient(configuration)

    def read_conversation(self, conversation_id: str, page: dict) -> str:
        response = self.sunco_client.MessagesApi().list_messages(
            self.sunco_app_id, conversation_id, page=page 
        )
        return json.dumps(response.to_dict())
    
    def send_message(self, conversation_id: str, message_body: dict) -> str:
        response = self.sunco_client.MessagesApi().post_message(
            self.sunco_app_id, conversation_id, message_body=message_body
        )
        return json.dumps(response.to_dict())

def get_app_scope_jwt(api_key='', api_secret='', account_id='', app_id=''):
    current_timestamp = time.time()

    headers = {
        'kid': api_key
    }

    data = {
        'scope': 'app',
        'iat': current_timestamp,
        'nbf': current_timestamp,
        'exp': current_timestamp + 600 # 10 mins expiry time
    }

    if account_id:
        data['zendeskAccountId'] = str(account_id)
    elif app_id:
        data['appId'] = app_id

    return jwt.encode(data, api_secret, algorithm='HS256', headers=headers).decode('utf-8')
