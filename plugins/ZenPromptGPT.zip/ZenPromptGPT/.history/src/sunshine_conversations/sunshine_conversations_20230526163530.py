import sunshine_conversations_client
import json
import requests

from datetime import datetime, timezone


class SunshineConversations:
    def __init__(
        self,
        sunco_app_id: str = None,
        sunco_api_key: str = None,
        sunco_api_secret: str = None,
    ):
        self.sunco_app_id = sunco_app_id
        self.sunco_api_key = sunco_api_key
        self.sunco_api_secret = sunco_api_secret
        configuration = sunshine_conversations_client.Configuration(
            host="https://api.smooch.io"
        )
        self.sunco_client = sunshine_conversations_client.ApiClient(configuration)

    

