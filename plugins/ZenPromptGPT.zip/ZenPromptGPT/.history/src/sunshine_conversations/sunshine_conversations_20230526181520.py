import json
import sunshine_conversations_client


class SunshineConversations:
    def __init__(
        self,
        sunco_app_id: str = None,
        sunco_api_key: str = None,
        sunco_api_secret: str = None,
    ):
        self.sunco_app_id = sunco_app_id
        configuration = sunshine_conversations_client.Configuration(
            host="https://api.smooch.io"
            api_key=self.sunco_api_key
        )
        self.sunco_client = sunshine_conversations_client.ApiClient(configuration)

    def read_conversation(self, conversation_id: str, page: dict) -> str:
        response = self.sunco_client.MessagesApi().list_messages(
            self.sunco_app_id, conversation_id, page=page 
        )
        return json.dumps(response.to_dict())
    
    def send_message(self, conversation_id: str, message_body: dict) -> str:
        response = self.sunco_client.MessagesApi().post_message(
            self.sunco_app_id, conversation_id, message_body=message_body
        )
        return json.dumps(response.to_dict())
