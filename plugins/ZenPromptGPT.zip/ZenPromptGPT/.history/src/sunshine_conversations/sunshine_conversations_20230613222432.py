import json
import sunshine_conversations_client
import time
import jwt


class SunshineConversations:
    def __init__(
        self,
        sunco_app_id: str = None,
        sunco_api_key: str = None,
        sunco_api_secret: str = None,
    ):
        self.sunco_app_id = sunco_app_id
        configuration = sunshine_conversations_client.Configuration(
            host="https://api.smooch.io",
        )
        configuration.access_token = get_app_scope_jwt(
            sunco_api_key, sunco_api_secret, app_id=sunco_app_id
        )
        self.api_client = sunshine_conversations_client.ApiClient(configuration)
        self.messages_api = sunshine_conversations_client.MessagesApi(self.api_client)

    def read_conversation(self, conversation_id: str) -> str:
        response = self.messages_api.list_messages(self.sunco_app_id, conversation_id)

        conversation = []
        for message in response.messages:
            m = {
                "text": message.content.text,
                "author": {
                    "type": message.author.type,
                    "name": message.author.display_name if message.author.display_name else "",
                }
            }
            conversation += m

        return json.dumps(conversation)

    def send_message(self, conversation_id: str, message: str) -> str:
        response = self.messages_api.post_message(
            self.sunco_app_id,
            conversation_id,
            {
                "content": {"type": "text", "text": message},
                "author": {"type": "business"},
            },
        )
        return json.dumps(response.to_dict())


def get_app_scope_jwt(api_key="", api_secret="", account_id="", app_id=""):
    current_timestamp = time.time()

    headers = {"kid": api_key}

    data = {
        "scope": "app",
        "iat": current_timestamp,
        "nbf": current_timestamp,
        "exp": current_timestamp + 604800,  # 1 week expiry time
    }

    if account_id:
        data["zendeskAccountId"] = str(account_id)
    elif app_id:
        data["appId"] = app_id

    return jwt.encode(data, api_secret, algorithm="HS256", headers=headers)
