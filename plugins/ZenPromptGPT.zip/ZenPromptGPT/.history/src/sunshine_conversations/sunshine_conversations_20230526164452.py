import sunshine_conversations_client


class SunshineConversations:
    def __init__(
        self,
        sunco_app_id: str = None,
        sunco_api_key: str = None,
        sunco_api_secret: str = None,
    ):
        self.sunco_app_id = sunco_app_id
        self.sunco_api_key = sunco_api_key
        self.sunco_api_secret = sunco_api_secret
        configuration = sunshine_conversations_client.Configuration(
            host="https://api.smooch.io"
        )
        self.sunco_client = sunshine_conversations_client.ApiClient(configuration)

    def read_conversation(self, conversation_id: str) -> str:
        response = self.sunco_client.ConversationApi().get_conversation(
            self.sunco_app_id, conversation_id
        )
        return json.dumps(response.to_dict())
