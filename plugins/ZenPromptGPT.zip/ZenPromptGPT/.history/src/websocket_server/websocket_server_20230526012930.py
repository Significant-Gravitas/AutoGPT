import asyncio
import websockets
from queue import Queue

class WebSocketServer:

    def __init__(self, host = "localhost", port = 8765) -> None:
        self.host = host
        self.port = port
        # Queues to store messages to be sent and received
        self.send_queue = Queue()
        self.receive_queue = Queue()

    async def websocket_handler(self, websocket, path = '/ws'):
        consumer_task = asyncio.ensure_future(self.consumer_handler(websocket))
        producer_task = asyncio.ensure_future(self.producer_handler(websocket))

        done, pending = await asyncio.wait(
            [consumer_task, producer_task],
            return_when=asyncio.FIRST_COMPLETED,
        )

        for task in pending:
            task.cancel()

    async def consumer_handler(self, websocket):
        async for message in websocket:
            self.receive_queue.put(message)

    async def producer_handler(self, websocket):
        while True:
            message = await asyncio.get_event_loop().run_in_executor(None, self.send_queue.get)
            await websocket.send(message)

    def start(self):
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        server = websockets.serve(self.websocket_handler, self.host, self.port)
        loorun_until_complete(server)
        loop.run_forever()

    def stop(self):

        pass
