# (Coming Soon) Auto-GPT-Plugin-Template
A starting point for developing your own plug-in for Auto-GPT
