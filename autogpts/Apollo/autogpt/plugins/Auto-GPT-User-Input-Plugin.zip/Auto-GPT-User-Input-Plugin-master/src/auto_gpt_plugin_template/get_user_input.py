def get_user_input(question_for_user: str) -> str:
    inp = input(question_for_user + "\n")
    return inp